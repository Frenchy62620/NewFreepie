def Saisir_data():
	var.sendCommand("SY;data!KD;79:78!K0!KK;5!KH;100!KU;79:78")
def CDU_WP():
	l = dcs.getDataSFromDCS()
	for i in range(len(l)):
		diagnostics.debug(str(i) + ': [' + l[i] + ']')
	if l[0] == 'N':
		beep.play(1000)

if speech.said("saisir données"):
	Saisir_data()
if speech.said("saisir chemin"):
	CDU_WP()

if starting:
	k = keyboard
	