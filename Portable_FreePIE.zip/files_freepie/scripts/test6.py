if speech.said("démarrage"):
	beep.play(300)
	dcs.setLasteWind()	
if starting:
	system.setThreadTiming(TimingTypes.HighresSystemTimer)
	system.threadExecutionInterval = 30
	#k, m, v = keyboard, mouse, vJoy[0]
	ddd= dcs
