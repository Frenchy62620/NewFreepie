if starting:
	system.setThreadTiming(TimingTypes.HighresSystemTimer)
	system.threadExecutionInterval = 30
	speech.selectVoice("ScanSoft Sebastien_Full_22kHz")
	d=dcs
	v = vJoy[0]

if speech.said("radio ALPHA"):
	var.sendCommand("A-10C_radio.txt", "VHF_A")
if speech.said("radio FOX"):
	var.sendCommand("A-10C_radio.txt", "VHF_F")
if speech.said("radio UHF"):
	var.sendCommand("A-10C_radio.txt", "UHF")
if speech.said("radio I L S"):
	var.sendCommand("A-10C_radio.txt", "ILS")
if speech.said("radio TACANE"):
	var.sendCommand("A-10C_radio.txt", "TACAN")
if speech.said("tester volet"):
	var.sendCommand("A-10C_radio.txt", "FLAPS")	
if keyboard.getPressed(Key.Space):
	diagnostics.debug(keyboard.getBuffer())