Armament Ground Safety Override Switch - SAFE

Utility Light - STOWED

EGI HQ TOD Switch - AS REQUIRED