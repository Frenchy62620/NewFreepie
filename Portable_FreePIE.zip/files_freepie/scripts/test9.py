if starting:
	system.setThreadTiming(TimingTypes.HighresSystemTimer)
	system.threadExecutionInterval = 30
	#speech.selectVoice("ScanSoft Sebastien_Full_22kHz")
	#######
	#j, t = joystick["Joystick - HOTAS Warthog"], joystick["Throttle - HOTAS Warthog"]
	#s = joystick["SideWinder Precision Racing Wheel USB version 1.0"]
	k, m = keyboard, mouse
	#k.azerty()
	#t.setRange(-100, 100, [2, 258]) 	# cursor radar cx, cy
	#t.setRange(0, 100, [1282, 1538])	# throttle left and right
	#######
	#speech.compile(["A10C_general.xml"])
	#speech.loadCFG(["A10C_general.cfg"])
	speech.compile(["A10C_master1.xml"])
	speech.loadCFG(["A10C_master1.cfg"])
	#speech.compile(["A10C_test_multi.xml"])
	#speech.loadCFG(["A10C_test_multi.cfg"])		
	#speech.compile(["A10C_general.xml", "A10C_test_multi.xml"])
	#speech.loadCFG(["A10C_general.cfg", "A10C_test_multi.cfg"])
	#speech.compile(["number.xml"])
	#speech.loadCFG(["number.cfg"])	

if speech.saidFromfile():
	diagnostics.watch(speech.result)