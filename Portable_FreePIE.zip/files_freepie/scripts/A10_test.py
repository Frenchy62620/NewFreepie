import socket
if starting:
	#sk = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
	#port = 7777
	#adrip = "192.168.1.165"
	system.setThreadTiming(TimingTypes.HighresSystemTimer)
	system.threadExecutionInterval = 30
	speech.selectVoice("ScanSoft Sebastien_Full_22kHz")
	#######
	EVENT, COMMAND = False, ""
	d = dcs
if speech.said("volets ouvert"):
	beep.play(600)
	#var.sendCommand("DX;FLAPS_SWITCH 2")
	var.sendCommand("DX;UFC_STEER 0!DX;UFC_STEER 1")
	#sk.close()
if speech.said("volets fermé"):
	beep.play(600)
	var.sendCommand("DX;FLAPS_SWITCH 0")
if speech.said("volets moitié"):
	beep.play(600)
	var.sendCommand("DX;FLAPS_SWITCH 1!DO;4256,65535,0:><:22600,23400!B0;4000")	
if speech.said("récupérer CDU"):
	beep.play(600)
	#var.sendCommand("DI;2:4544:24:4760")
	a = ""
	#for i in range(0,10):
	a = dcs.getData(4544 + 0 * 24  ,240)
	diagnostics.debug(a)
	#sk.sendto(a, ("192.168.1.173", 6666) )
		
if speech.said("saisir données"):
	Saisir_data()
if speech.said("papa tango"):
	ss = next((s for s in bx if "L/L" in s), None)
	if ss:
		diagnostics.debug(ss)
	else:
		beep.play(200)	
