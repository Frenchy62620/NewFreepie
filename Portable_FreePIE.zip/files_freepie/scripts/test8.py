if starting:
	cmd = ""
	k = keyboard

def Saisir_data():
	var.sendCommand("SY;data!KD;79:78!K0!KK;5!KH;100!KU;79:78")
def CDU_WP():
	l = dcs.getDataSFromDCS()
	l =["N", "L", "NAV01", "000406", "0414154", "415451", "8000"]
	for i in range(len(l)):
		diagnostics.debug(str(i) + ': [' + l[i] + ']')
	cmd = "DW;CDU_:100" + ":WP:LSK_3R" + (":LSK_7R" if l[0] == 'N' else "") + (":LSK_9R" if l[1] == 'U' else "")
	for i in range(2, len(l)):
		if len(l[i]) == 0 or (l[i][0] == '-' and len(l[i]) == 1):
			continue
		for c in l[i]:
			cmd += ":{0}".format(c)
		if i == 2:		#WP Exist?
			cmd += ":LSK_3R" if l[0] != 'N' else ""
		elif i == 3:	#DTOT
			cmd += ":LSK_5R"
		else:			#Lat, Lon or Elevation
			cmd += ":LSK_{0}L".format( 5 if i == 6 else 9 if len(l[i]) > 6 else 7)
	diagnostics.watch(cmd)
		

if speech.said("saisir données"):
	Saisir_data()
if speech.said("saisir chemin"):
	CDU_WP()


	