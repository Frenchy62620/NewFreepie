if starting:
	system.setThreadTiming(TimingTypes.HighresSystemTimer)
	system.threadExecutionInterval = 30
	speech.selectVoice("ScanSoft Sebastien_Full_22kHz")
	#######
	j, t = joystick["Joystick - HOTAS Warthog"], joystick["Throttle - HOTAS Warthog"]
	s = joystick["SideWinder Precision Racing Wheel USB version 1.0"]
	k, m, v = keyboard, mouse, vJoy[0]
	#k.azerty()
	t.setRange(-100, 100, [2, 258]) 	# cursor radar cx, cy
	t.setRange(0, 100, [1282, 1538])	# throttle left and right
	#######
	speech.compile(["A10C_cdu1.xml"])
	speech.loadCFG(["A10C_cdu1.cfg"])
	sw0 = sw1 = paddle = viewon = False
	trim = [36, 37, 38, 39]
	lim = 0.9 * 16383
	view, lastview =[5, 6, 5, 4] ,[-1, -1, -1, -1]
	#var.lapseSingleClick = 175
	thrX, vjoyX = [0, 100] , [16383,-16383] #t.MinMaxAxis(4),v.MinMaxAxis
	led1, led2, led3, led4, led5, backlight = 0x1, 0x10, 0x100, 0x1000, 0x10000, 0x100000

if speech.saidFromfile():
	exec(speech.result)

def cdu(cdukey, id)
	diagnostics.watch(speech.result)
	#k.setPressed([Key.LeftCtrl, Key.LeftWindowsKey, cdukey])
