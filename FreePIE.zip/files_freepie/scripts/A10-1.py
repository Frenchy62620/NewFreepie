if starting:
	system.setThreadTiming(TimingTypes.HighresSystemTimer)
	system.threadExecutionInterval = 30
	speech.selectVoice("ScanSoft Sebastien_Full_22kHz")
	#######
	j, t = joystick["Joystick - HOTAS Warthog"], joystick["Throttle - HOTAS Warthog"]
	s = joystick["USB  ADAPTOR"] #s = joystick["SideWinder Precision Racing Wheel USB version 1.0"]
	k, m, v = keyboard, mouse, vJoy[0]
	ddd = dcs
	t.setRange(-100, 100, [2, 258]) 	# cursor radar cx, cy
	t.setRange(0, 100, [1282, 1538])	# throttle left and right
	s.setRange(0, 100, [2, 258]) 		# frein differentiel L & R
	#######
	#speech.compile(["A10C_general.xml", "A10C_cdu.xml"])
	speech.compile(["A10C_master.xml"])
	speech.loadCFG(["A10C_master.cfg"])
	#speech.setCFG(["cdu"], False)
	sw0 = sw1 = paddle = viewon = False
	trim = [36, 37, 38, 39]
	lim = 0.9 * 16383
	view, lastview =[5, 6, 5, 4] ,[-1, -1, -1, -1]
	thrX, vjoyX = [0, 100] , [16383, -16383] #t.MinMaxAxis(4),v.MinMaxAxis
	led1, led2, led3, led4, led5, backlight = 0x1, 0x10, 0x100, 0x1000, 0x10000, 0x100000
	tirpause = Key.Console; tircentre = Key.NumberPad5
	ii = 0

if speech.saidFromfile():
	exec(speech.result)
	diagnostics.watch(speech.result)

if speech.said("saisir données"):
	Saisir_data()
if speech.said("saisir chemin"):
	CDU_WP()

if speech.said("séquence startup"):
	var.sendCommand("A-10C_startup1.txt", "STARTUP")

if speech.said("séquence cheutdone"):
	var.sendCommand("A-10C_startup1.txt","SHUTDOWN")

if speech.said("saisir balisage"):
	beep.play(600)
	var.sendCommand("A-10C_cdu.txt","NEW_WAYPOINT")

if speech.said("saisir données"):
	beep.play(600)
	var.sendCommand("KD;78:79!K0!KK;5!KU:100!KU;79:78")
if speech.said("récupérer données"):
	beep.play(600)
	b = dcs.getDataSFromDCS()
	for c in b:
		diagnostics.debug(c)	
if speech.said("fréquence ALPHA"):
	beep.play(300)
	var.sendCommand("A-10C_radio.txt", "VHF_AM")
if speech.said("fréquence FOX"):
	beep.play(300)
	var.sendCommand("A-10C_radio.txt", "VHF_FM")
if speech.said("fréquence UHF"):
	beep.play(300)
	var.sendCommand("A-10C_radio.txt", "UHF")	
if speech.said("saisir course"):
	var.sendCommand("A10-C_radio.txt", "COURSE_KNOB");
if speech.said("saisir pression"):
	var.sendCommand("A10-C_pressure.txt");
aerofrein = keyboard.getKeyDown(Key.Insert)

#if speech.said("boum"):
#	k.setPressedNow([Key.LeftCtrl, Key.LeftShift, Key.F1])
#	k.setPressedNow([Key.LeftCtrl, Key.LeftShift, Key.F1])
#
#if speech.said("vue droite"):
#	k.setPressedNow([Key.RightCtrl, Key.NumberPad0])
#	k.setPressed([Key.NumberPad6])
#if speech.said("stoppper vue"):
#	k.setPressedNow([Key.RightCtrl, Key.NumberPad0])

############################ Pedal Axis (Sidewinder) ########################################
#pedalL, pedalR = s.zRotation, s.y															#
#rudder = filters.CurveL((pedalL - pedalR)/2, 16383, .01, .01, 1)							#
pedal = s.zRotation																			#
rudder = filters.CurveL(pedal, 16383, .03, .03, 1)											#
freinL = filters.CustomCurveL(s.x * 2 if s.x < 51 else 100, [0,0, 5,0, 95,100, 100,100])	#
freinR = filters.CustomCurveL(s.y * 2 if s.y < 51 else 100, [0,0, 5,0, 95,100, 100,100])	#
																							#
BrakeL = -filters.mapRange(freinL, thrX[0], thrX[1], vjoyX[0], vjoyX[1] )					#
BrakeR = -filters.mapRange(freinR, thrX[0], thrX[1], vjoyX[0], vjoyX[1] )					#
#############################################################################################

############################ Joystick HOTAS #################################################
############################ Joystick Axis													#
roll = filters.CurveL(j.x, 16383, .01, .01, 1)												#
pitch = filters.CurveL(j.y, 16383, .01, .01, 1)												#
############################ Joystick Pov													#	
dir = var.get4Ways(j.pov[0]) 																#
############################ Joystick Buttons												#
sw0 = j.getDown(3) 													#sw0					#
sw1 = not sw1 if var.dblClicked(sw0) else sw1                       #sw1               		#
#																							#
trig1, trig2, wpnrel = j.getDown(0), j.getDown(5), j.getDown(1)		#gun PAC, fire, wpn rel	#
master_mode, nws_laser = j.getDown(4, not sw1), j.getDown(2)		#master mode/NWS_Laser	#
#############################################################################################

############################ Throttle HOTAS #################################################
############################ Throttle Axis													#
# Throttle gauche et droitet.z, t.zRotation in [0 - 100]  									#
thr_left, thr_right = 100 - t.zRotation, 100 - t.z											#									
thr_left = filters.mapRange(thr_left, thrX[0], thrX[1], vjoyX[0], vjoyX[1])					#
thr_right = filters.mapRange(thr_right, thrX[0], thrX[1], vjoyX[0], vjoyX[1])				#
# Cursor radar X / Y																		#
cx, cy  = t.x, t.y																			#
# range_knob                                                                            	#
zoom = t.sliders[0]																			#
############################ Throttle Buttons												#
spbrkin = t.getDown(6)							 	   			   #speedbrake				#
spbrkout = t.getDown(7) or aerofrein						        						#
boat_fw, boat_bk = t.getDown(8), t.getDown(9)                      #boat	            	#
china_fw, china_bk = t.getDown(10), t.getDown(11)                  #china   	        	#
pinky_fw, pinky_bk = t.getDown(12), t.getDown(13)                  #pinKey              	#
flapsup, flapsdn = t.getDown(21), t.getDown(22)                    #flaps 					#
# radio																						#
vhf1_fw, uhf_dn, vhf2_bk = t.getDown(3), t.getDown(4), t.getDown(5)							#
ts_up = t.getDown(2)																		#
# LASTE Gestion																				#
eac, rdr =  t.getDown(23), t.getDown(24)                                      				#
apeng, appath, apalt = t.getDown(25), t.getDown(26), t.getDown(27)                      	#
# Engine 																					#
apu, ldgwarning_caution = t.getDown(19), t.getDown(20)										#
eng_fuel_l, eng_fuel_r = t.getDown(15), t.getDown(16)										#
eng_oper_motor_l, eng_oper_motor_r = t.getDown(17), t.getDown(18)							#
eng_oper_ign_l, eng_oper_ign_r = t.getDown(30), t.getDown(31)								#
cutoff_r, cutoff_l = t.getDown(28), t.getDown(29)											#
#############################################################################################

warthog.setLed([0], sw0 or sw1)

########################### RUDDER to action ################################################
v.z, v.ry, v.rz = rudder, BrakeL, BrakeR													#
#############################################################################################

########################### Joystick HOTAS to action ########################################
v.x, v.y = roll, pitch																		#
#																							#
v.setDigitalPov(0, var.get4Ways(j.getDown([6, 7, 8, 9], not sw0)))	#tms                    #
v.setDigitalPov(1, var.get4Ways(j.getDown([10, 11, 12, 13])))		#dms                    #
v.setDigitalPov(2, var.get4Ways(j.getDown([14, 15, 16, 17])))		#cms                    #
#																							#
v.setButton(44, master_mode)										#master mode			# 
v.setButton([40, 45, 41, 02], [trig1, trig2, wpnrel, nws_laser])	#canon, release & nws	#
																							#
# View	[ , r, u, l] last view                                     							#
#if not sw0 and not sw1:																	#
#	if var.getPressed(dir >=0):					                                          	#
#		joydir = dir                                                                        #
#	timerdir = var.heldDown(dir >= 0, 500)                                                	#
#	if var.getPressed(timerdir):                                                            #
#		viewon = not viewon                                                                 #
#		k.setPressed([Key.RightCtrl, Key.NumberPad0, Key.O])		#view cockpit & tir ctr #
#		lastview[0] = -2																	#
#	if var.getReleased(dir >= 0):                                                           #
#		if lastview[0] == -2:																#
#			lastview[0:4] = [-1, -1, -1, -1]												#
#		if viewon:                                              	                        #
#			dispview()													            	    #
#		else:                                                                               #
#			k.setPressed([Key.F1], joydir == 0)						#view cokpit        	#
#			k.setPressed([Key.F4], joydir == 2)	            		#view rear	        	#
#                                                                                           #
#def dispview():																			#
#	if view[joydir] == lastview[joydir]:                                 					#
#		view[joydir] = 9 if view[joydir]== 6 else (view[joydir] + 3) % 9	            	#
#	joykey = [k.intTOkey(int(Key.NumberPad0) + view[joydir])]		          	        	#
#	k.setPressed(joykey)                                                             		#
#	lastview[1:4] =[-1, -1, -1]; lastview[joydir] = view[joydir]; lastview[0] = -1			#
#																							#
#############################################################################################
                                                                                         
########################### Throttle HOTAS to action ########################################
v.slider, v.dial = thr_left, thr_right                                                    	#
#v.rx = zoom if not sw0	else v.rx										#zoom FOV           #
# cursor radar u,r,d,l																		#
v.setDigitalPov(3, var.get4Ways(98, Axis.XY, cx, -cy))										#
#																							#
v.setButton([32, 33, 34, 35], var.get4Ways(t.pov[0]))					#coolie				#
v.setButton([6, 7, 8, 9], [spbrkin, spbrkout, boat_fw, boat_bk])		#speedbrake, boat   #
v.setButton([10, 11, 12, 13], [china_fw, china_bk, pinky_fw, pinky_bk]) #china, pinky      	#
v.setButton([21, 22], [flapsup, flapsdn])								#flaps              #
# Autopilote LASTE                                                							#
v.setButton([23, 24, 25, 26, 27], [eac, rdr, apeng, appath, apalt])                        	#
# engine																					#
v.setButton([19, 28, 29], [apu, cutoff_r, cutoff_l])					#apu & engine		#
v.setButton([15, 16], [eng_fuel_l, eng_fuel_r])							#fuel flow			#
v.setButton([17, 18], [eng_oper_motor_l, eng_oper_motor_r])				#eng oper motor		#
v.setButton([30, 31], [eng_oper_ign_l, eng_oper_ign_r])					#eng oper ign		#
v.setButton([20, 42], ldgwarning_caution)								#stop alarms 		#
# radio																						#
v.setButton([3, 4, 5], [vhf1_fw, uhf_dn, vhf2_bk])						#vhf & uhf			#
																							#
################################ Switch #####################################################
if not sw0 and not sw1:		#No switch		 												#
	v.rx = zoom				#zoom = t.sliders[0]							#zoom FOV       #
	v.setButton(trim, dir)	#POV joy										#trim norm/sec	#	
	v.setDigitalPov(0, var.get4Ways(j.getDown([6, 7, 8, 9], not sw0)))		#tms            #
elif sw0 and not sw1:		#Function switch0 												#
	####################### Joystick HOTAS to action ########################################
	v.setButton(43, j.getPressedBip(18, 1000))	#button 18 push cms	#RAZ TRIM				#
	k.setPressed([Key.NumberPad5, Key.O], j.getPressed(6))			#view & tir center   	#	
	k.setPressed([Key.RightCtrl, Key.O], j.getPressed(8))			#tir pause				#
	v.setButton([60, 61], j.getDown([9, 7]))						#seatdn, seatup 		#
	####################### Throttle HOTAS to action ########################################
	geardn = var.get3States(zoom > lim)							    #gear down				#
	gearup = var.get3States(zoom < -lim)		                    #gear up				#
	v.setButton([62, 63], [gearup[0], geardn[0]])	            							#
	speech.say([gearup[1], geardn[1]], ["Train rentré", "Train sorti"])						#
	####################### Function switch1 ################################################
elif sw1 and not sw0:		#Function switch1 												#
	####################### Joystick HOTAS to action ########################################	
	#TRIM	[36, 37, 38, 39]	TRIM SECOURS [56, 57, 58, 59]	bug 56 58 inverse			#
	if j.getPressed(8):								#switch Norm/secours					#		
		trim = map(lambda x: x-20 if x > 50 else x+20, trim); sec = trim[0]>50				#
		v.setPressed(46)							#set norm or sec EFCP_TRIM_OVERRIDE	0/1	#
		speech.say([not sec, sec], ["compensateur normal", "compensateur de secours"])		#
else:						#Function sw0 and sw1											#
	pass																					#	
#############################################################################################


def radio(device, cmd):
	#AddCommandFromVar(cmd, 2)
	device.setPressed(cmd)
def tacan():
	var.AddCommandFromFile("A-10C_radio.txt", "TACAN")
def ils():
	var.AddCommandFromFile("A-10C_radio.txt", "ILS")
def vhf(i):
	var.AddCommandFromFile("A-10C_radio.txt", "VHF_" + i)
def keybut(keys, buttons, id):
	k.setPressedLater(keys, 600, id); v.setPressed(buttons, 500, id)
def mousevjoy(mouse, buttons, id):
	m.setPressedLater(mouse, 600, id); v.setPressedLater(buttons, 500, id)

def cdu(cdukey):
	k.setPressed([Key.LeftCtrl, Key.LeftWindowsKey, cdukey])
def camera(sens):
	k.setPressedLater([Key.RightCtrl, Key.RightShift, sens], 1000, 10)
	k.setPressedLater([Key.NumberPad2], 500, 11)
def tir(action):
	if action == 1:
		k.setPressed(Key.NumberPad5)		#center
	if action == 2:
		k.setPressed([Key.LeftCtrl, Key.O])	#pause

if speech.said("mission plan de vol"):
	beep.play(300)
	CDU_AddWP()
if speech.said("ajoute plan de vol"):
	beep.play(300)
	CDU_AddFPM()

def CDU_AddWP():
	CDU_WP(["N", "L", "N1", "*", "414151", "0415451", "8000"])
	CDU_WP(["N", "L", "N2", "*", "415737", "0421342", "10000"])
	CDU_WP(["N", "U", "N3", "*", "37T", "GG2923661948", "12000"])      #GG2923661948 37T WG84                                              
	CDU_OSET(["O", "L", "N4", "*", "BULL", "030033", "8000"])

def CDU_AddFPM():
	CDU_FPM(["ABC", "N1", "N2", "N3", "N4", "N"])

def CDU_WP(data):	#	["New/Exist", "L/U", "NAME", "DTOT", "LONG", "LAT", "ELEVATION"]
	#l = dcs.getDataSFromDCS()
	cmd = ["DW;CDU_:100:WP:LSK_3R"]
	namewp = (":{}"*len(data[2])).format(*list(data[2]))
	umts = ":LSK_9R" if data[1] == "U" else ""
	cmd.append(namewp); cmd.append(":LSK_{0}R{1}".format(7 if data[0] == 'N' else 3, umts))
	for i in range(4, 7):
		if len(data) > i and len(data[i]) > 1:
			cmd.append((":{}"*len(data[i])).format(*list(data[i])))
			cmd.append(":LSK_{0}L".format((7, 9, 5)[i - 4]))		
	cmd.append(umts)
	if len(data) > 3 and len(data[3]) == 6:
		cmd.append((":{}"*6).format(*list(data[3]))); cmd.append(":LSK_5R")
	var.sendCommand(''.join(cmd))

def CDU_OSET(data):	# ["N/E", "L/U", "NAME", "DTOT", "INIT", "HHHDDD", "ELEVATION"]
	cmd = ["DW;CDU_:100:OSET"]
	namewp = (":{}"*len(data[2])).format(*list(data[2]))
	umts = ":LSK_3R" if data[1] == "U" else ""
	for i in range(4, 6):
		if len(data) > i and len(data[i]) > 1:	
			cmd.append((":{}"*len(data[i])).format(*list(data[i])))
			cmd.append(":LSK_5L" if i == 4 else ":LSK_5R")
	cmd.append(namewp); cmd.append(":LSK_7R")
	cmd.append(":WP:LSK_3R"); cmd.append(namewp); cmd.append(":LSK_3R")
	if len(data) > 6 and len(data[6]) > 1:
		cmd.append((":{}"*len(data[6])).format(*list(data[6]))); cmd.append(":LSK_5L")	
	if len(data) > 3 and len(data[3]) == 6:	
		cmd.append((":{}"*6).format(*list(data[3]))); cmd.append(":LSK_5R") 
	var.sendCommand(''.join(cmd))

def CDU_FPM(data):	#	["namefpm", "nbwp", "n", "A"]
	#nbwp = int(data[1])
	cmd = ["DW;CDU_:100:FPM"]
	cmd.append((":{}"*len(data[0])).format(*list(data[0]))); cmd.append(":LSK_9L:LSK_5R")
	for w in reversed(data[1:-1]):
		cmd.append((":{}"*len(w)).format(*list(w))); cmd.append(":LSK_3R:LSK_5L")
	cmd.append(":FPM")	
	if data[-1] == "A":
		cmd.append(":LSK_5L:LSK_5L")
	var.sendCommand(''.join(cmd))

def CDU_WINDLASTE():
    #data = dcs.getDataIFromDCS()
    data = [38,-7, 4,55, 6,130, 9,224]
    cmd = ""
    j, l, alt = [2, 2, 2, 4, 6], [5, 7, 9, 3, 5], [0, 1, 2, 7, 26]
    for i in range(5):
        windto = data[j[i] + 1]
        windfrom = windto + data[1] + (-180 if windto > 180 else 180)
        if windfrom < 1:
            windfrom += 360;
        windspeed = data[j[i]]
        windspeed = round(1.94 * (windspeed * (2 if i== 1 or i == 2 else 1)), 0)
        if i == 3:
            cmd.append("DF;CDU_PG :300:0:1!")
        lg = list("{0:03d}{1:02d}{2}".format(windfrom, windspeed, l[i]))
        cmd.append("DW;CDU_:300:{0}:{1}:{2}:{3}:{4}:LSK_{5}L!".format(*lg))
    cmd.append("DF;CDU_PG :300:2:1!")
    for i in range(5):
        temp = data[0] - 2 * alt[i]
        if i == 3:
            cmd.append("DF;CDU_PG :300:0:1!")
        lg = list("{0:D2}{1:D1}".format(abs(temp), l[i]))
        cmd.append("DW;CDU_:300:{0}:{1}:LSK_{2}R" + (":LSK_{2}R" if temp < 0 else "").format(*lg))
    var.sendCommand(cmd)

#def ll():    
#    j, l, alt = [2, 2, 2, 4, 6], [5, 7, 9, 3, 5], [0, 1, 2, 7, 26]
#    for i in range(0, 5):
#        windto = data[j[i] + 1]
#        windfrom = windto + data[1] + (-180 if windto > 180 else 180)
#        if windfrom < 1:
#            windfrom += 360
#        windspeed *= 2
#        windspeed = int(round(1.94 * data[j], 0))if i == 0 or i > 2 else int(round(1.94 * data[j] * 2, 0))
#        number = list("{0:03d}{1:02d}".format(windfrom, windspeed))
#        number.append(l)
#        wind = "D0;WCDU_:300:{0}:{1}:{2}:{3}:{4}!D0;ZCDU_LSK_{5}L".format(*number)
#        data.append(wind)
#        tempc = data[0] - 2 * alt)
#        neg = True if temp < 0 else False
#        number = list("{0:02d}".format(math.abs(temp))
#        if neg:
#            temp = "D0;ZCDU_{0}!D0;ZCDU_{1}!D0;ZCDU_LSK_{2}L!D0;ZCDU_LSK_{2}L".format(*number)
#        else
#            temp = "D0;ZCDU_{0}!D0;ZCDU_{1}!D0;ZCDU_LSK_{2}L".format(*number)
#        data.append(temp)         #temp (c)
#    data[0:8] = []
#    for i in data:
#        diagnostics.debug("index : {0}, val = {1}", data.index(i), i)    
#

def Saisir_data():
	var.sendCommand("SY;data!KD;79:78!K0!KK;5!KH;100!KU;79:78")
"""
sw0 = switch on, sw1 = toogle dblclicked(sw0)
Throttle 			sw0				Joystick			sw0				Vjoy			
----------------------------------------------------------------------------------------			
00	cursorE							00	trig1							00  			    32  coolie u				64   
01       							01	wpn_rel         		        01  			    33  coolie r                65   
02  mic up  						02	nws/laser	      		       	02  nws/laser	    34  coolie d                66   
03	mic fw 							03  ***sw0***       ***sw1***       03  mic fw	    	35  coolie l                67   
04  mic dn 							04	master_mode       			    04  mic dn		    36  trim nose d  seatdown   68  trim secours          
05  mic bk							05	trig2           		        05  mic bk         	37  trim roll r  seatup     69  trim secours          
06  spbrkout						06	tms	up		    view/tir center 06  spbrkin         38  trim nose d             70	trim secours 
07  spbrkin							07	tms	right	    seatup	        07  spbrkout	    39  trim roll l	            71	trim secours 
08  boat fw							08	tms	down		tir_pause	    08	boat fw         40	trig1                   72	coolie u vocal 
09  boat bk							09	tms	left		seatdn		    09	boat bk         41	wpnrel                  73  coolie r vocal 
10  china fw						10  dms	up		    		        10	china fw        42	master_caution(20)      74        
11	china bk						11  dms	right	    		        11	china bk        43  RAZ trim                75	coolie l vocal 
12  pinky fw           		    	12  dms	down	    		        12  pinky fw       	44  master_mode             76                        
13  pinky bk           		    	13  dms	left	    		        13  pinky bk       	45	trig2                   77	                      
14  apeng2                		    14  cms	up		    		        14			        46  Compens. norm/secours   78	                      
15  engfuel_l         		        15  cms	right	    		        15	engfuel_l       47	                        79	                      
16  engfuel_r          		        16  cms	down	    		        16	engfuel_r       48	                        80	                      
17  engopermotor_l     		        17  cms	left	    		        17	engopermotor_l  49	                        81                        
18  engopermotor_r     		        18  push 					        18	engopermotor_r  50	                        82	                      
19  apu                		                          		        	19  apu  			51                          83                        
20  ldg_warning				                          		        	20	ldg_warning(42) 52	                        84                        
21  flapsup		        	                          		        	21  flapsup         53                          85                        
22  flapsdn		        	                          		        	22  flapsdn         54                          86                        
23  eac                		                          		        	23  eac		        55                          87                        
24  rdr                		                          		        	24  rdr		        56 trimsec nose d  	        88                        
25  apeng	          		                          		        	25  apeng           57 trimsec roll r           89                        
26  appath					                          		        	26  appath		    58 trimsec nose d           90	                      
27  apalt   		                          		        			27  apalt		    59 trimsec roll l           91	                      
28  eng_r_cutoff       		                          		        	28	eng_r_cutoff    60	                        92	              
29  eng_l_cutoff       		                          		        	29	eng_l_cutoff    61	                        93                
30                  		                          		        	30	engoperign_l    62	gearup           
31                  		                          		        	31	engoperign_r    63  geardn                    
															 
0U	coolie u						0U	Cockpit view					0U	tms	up			1U  dms	up		
0R  coolie r                        0R  							   	0R	tms	right		1R  dms	right	
0D  coolie d                        0D 	Rear View					   	0D	tms	down		1D  dms	down	
0L  coolie l                        0L  							   	0L	tms	left		1L  dms	left	
  								   2x0D	reset Zoom						
slider	 			    		    	                                2U  cms	up		3U	radar curs u
-------------------------------------------------------------------     2R  cms	right	3R	radar curs r
u 	Zoom FOV + 		U gearup                                            2D  cms	down	3D	radar curs d                                                                        
d   Zoom FOV -     	D geardn                                            2L  cms	left	3L	radar curs l
                                                                        
                                                                        
curseur																																			
-------------------------------------------------------------------		
cx	curs l/r        AZIMUTH/BAR scan change              		        
cy  curs u/d        range radar +/-                                     
                                                                        
                                                                        
frein appuye = pedalG + R appuy�e 1s (toggle)

  <Joystick_Name ID="1">Joystick - HOTAS Warthog</Joystick_Name>
  <Joystick_Char Buttons="19" Axis="2" POV="1">
    <AXIS Id="2" MinVal="0" MaxVal="65535">Axe X</AXIS>
    <AXIS Id="258" MinVal="0" MaxVal="65535">Axe Y</AXIS>

  <Joystick_Name ID="4">Throttle - HOTAS Warthog</Joystick_Name>
  <Joystick_Char Buttons="32" Axis="5" POV="1">
    <AXIS Id="2" MinVal="0" MaxVal="65535">Axe X</AXIS>
    <AXIS Id="258" MinVal="0" MaxVal="65535">Axe Y</AXIS>
    <AXIS Id="514" MinVal="0" MaxVal="65535">Curseur</AXIS>
    <AXIS Id="1282" MinVal="0" MaxVal="65535">Rotation Z</AXIS>
    <AXIS Id="1538" MinVal="0" MaxVal="65535">Axe Z</AXIS>

  <Joystick_Name ID="3">SideWinder Precision Racing Wheel USB version 1.0</Joystick_Name>
  <Joystick_Char Buttons="8" Axis="3" POV="0">
    <AXIS Id="2" MinVal="0" MaxVal="65535">Axe X</AXIS>
    <AXIS Id="258" MinVal="0" MaxVal="65535">Axe Y</AXIS>
    <AXIS Id="1282" MinVal="0" MaxVal="65535">Rotation Z</AXIS>

v.slider, v.dial = thr_left, thr_right                                                      #
v.rx = zoom if not sw0	else v.rx										#zoom FOV
v.x, v.y, v.z = roll, pitch, rudder	
"""