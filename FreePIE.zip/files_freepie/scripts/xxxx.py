if starting:
	system.setThreadTiming(TimingTypes.HighresSystemTimer)
	system.threadExecutionInterval = 30
	speech.selectVoice("ScanSoft Sebastien_Full_22kHz")
	t = dcs
	#A10C.readfile()
	LFMC = 0
	ZOZO = LFMC
	u0 = u1 = u2 = ""
	v = 0
#u0 = dcs.getData("CDU_LINE9")[1:8]
if keyboard.getKeyDown(Key.LAlt) and keyboard.getKeyDown(Key.LeftShift):
	u1 = u0[:6]
	u2 = u0[-1:]
#obj = dcs.getData("CMSP1")
#diagnostics.watch("{" + obj+ "}")
u0 = int(dcs.getData("VHFAM_FREQ1", 1)) * 10 + dcs.getData("VHFAM_FREQ2")
u1 = dcs.getData("VHFAM_FREQ3") * 100 + int(dcs.getData("VHFAM_FREQ4", 1))
#LFMC = dcs.getData("LMFD_PWR")

vhfam = str(u1) + "." + str(u2)
#diagnostics.watch("LMFD_PWR: [" + u1 + "]")
diagnostics.watch("VHFAM: [" + vhfam + "]")
diagnostics.watch("VHFAM: [" + str(u0) + "." + str(u1)+ "]")
if speech.said("résultat"):
	speech.say(str(LFMC))	
if keyboard.getPressed(Key.D5):
	dcs.readfile("E:\\file.bin")
	beep.play(300)
	dcs.sendCommand(["SAI_CAGE TOGGLE"])
if speech.said("bonjour"):
	beep.play(300)
	#ZOZO = 0 if LFMC==2 else LFMC+1
	#speech.say(str(ZOZO))	
	dcs.sendCommand(["SAI_CAGE 0"])
	#dcs.sendCommand(["LMFD_PWR " + str(ZOZO)])