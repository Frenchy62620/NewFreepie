#from ctypes import windll
if starting:
	#y = 0
	#x = windll.kernel32.GetTickCount() 	
	system.setThreadTiming(TimingTypes.HighresSystemTimer)
	system.threadExecutionInterval = 30
	speech.selectVoice("ScanSoft Sebastien_Full_22kHz")
	j, t = joystick["Joystick - HOTAS Warthog"], joystick["Throttle - HOTAS Warthog"]
	s = joystick["SideWinder Precision Racing Wheel USB version 1.0"]
	t.setRange(-100, 100, [2, 258]); t.setRange(0, 100, [1282, 1538])
	k, ky = keyboard, Key
	v = vJoy[0]
	speech.compile(["F16_general.xml"]); speech.loadCFG(["F16_general.cfg"])
	ctrl_f1, ctrl_f2  = [ky.LeftCtrl, ky.F1], [ky.LeftCtrl, ky.F2]
	alt_f1, alt_f2  = [ky.LeftAlt, ky.F1], [ky.LeftAlt, ky.F2]		
	switch2 = paddle = False
	lim = 0.9 * 16383
	mode = offset = pitch_mode = roll_mode = 0
	#var.lapseSingleClick = 175
	modetext = ["Mode Navigation", "Mode Air Air", "Mode Air Sol"]
	naudio.cacheSound(1, "magswitch_in.ogg")
	naudio.cacheSound(2, "magswitch_out.ogg")
	thrX, vjoyX = [0, 100] , [16383,-16383] #t.MinMaxAxis(4),v.MinMaxAxis
	led1, led2, led3, led4, led5, backlight = 0x1, 0x10, 0x100, 0x1000, 0x10000, 0x100000

"""
y =windll.kernel32.GetTickCount() - x
x = windll.kernel32.GetTickCount()		
diagnostics.debug(y)
"""
"""
if var.getPressed(falcon4.isInGame()):
	diagnostics.watch(falcon4.isInGame())
	beep.play(200,200)
"""
"""
if speech.said("HSD+"):
	beep.play(600, 300); k.setPressed([ky.LeftCtrl, ky.F3])
if speech.said("HSD-"):
	beep.play(100, 300); k.setPressed([ky.LeftCtrl, ky.F4])

if speech.said("Balise +"):
	beep.play(600, 300); k.setPressed(ky.X)
if speech.said("Balise -"):
	beep.play(100, 300); k.setPressed(ky.W)
	
if speech.said("Curseur0"):
	k.setPressed(ky.PageUp)
if speech.said("Curseur enable"):
	beep.play(200, 200)
	k.setPressed(ky.Insert)

if speech.said("radio awacs"):
	k.setPressed(ky.A)
if speech.said("contact tour"):
	k.setPressed(ky.T)
if speech.said("radio tanker"):
	k.setPressed(ky.Y)
"""

if speech.saidFromfile():
	exec(speech.result)
	




############################ Pedal Axis (Sidewinder) ########################################
pedalL, pedalR = s.zRotation, s.y															#
rudder = filters.CurveL((pedalL - pedalR)/2, 16383, .01, .01, 1)							#
#############################################################################################

############################ Joystick HOTAS #################################################
############################ Joystick Axis													#
roll = filters.CurveL(j.x, 16383, .01, .01, 1)												#
pitch = filters.CurveL(j.y, 16383, .01, .01, 1)												#
############################ Joystick Buttons												#
sw0 = j.getDown(3) 										# sw0								#
#																							#
trig1, trig2 = j.getDown(0), j.getDown(5)													#
############################ Throttle HOTAS #################################################
############################ Throttle Axis													#
# t.z € [0 - 100]    																		#
thr_right = filters.CustomCurveL(100 - t.z, [0,5, 65,70, 75,70, 100,100])	   				#
thr_left = t.zRotation																		#
# Cursor radar X / Y																		#
cx, cy  = t.x, t.y																			#
# range_knob                                                                            	#
range_knob = t.sliders[0]																	#
# simulate click at 70% = just before AB (up) or quit AB led 5 ligth on						#
if var.getPressed(thr_right == 70):															#
	naudio.playSound(1); warthog.setOn(backlight)                 		                	#
# simulate click when quit 70%   if 70%  (mil thrust)                                   	#
if var.getReleased(thr_right == 70):														#
	naudio.playSound(2); warthog.setOff(backlight)											#
#############################################################################################
# idlcutoff starting and stopping engine											    	#
# dont forget to check idlecutoff in falcon configuration (hardware)						#
thr_right = filters.mapRange(thr_right, thrX[0], thrX[1], vjoyX[0], vjoyX[1] )				#
idlecutoff = t.get3States(28)                                				    			#
if idlecutoff[1]:                                                      				    	#
	offset = 16383 / 1024 * 90                                         				    	#
if idlecutoff[2]:                                                      				    	#
	offset = 0                                                         				    	#
############################ Throttle Buttons												#
spbrkin, spbrkout = t.getDown(6), t.getDown(7)  				   #speedbrake	        	#
#############################################################################################



warthog.set(0x000001, sw0)

if var.dblClicked(sw0):
	switch2 = not switch2
	warthog.setLed(0x100000, switch2)
	beep.play(switch2, [1000, 500], [150, 500])	

wpn_rel = j.getDown(1)
pinky = j.getDown(2)
nws_msl = j.getDown(4)
trim = j.pov[0]

vhf = t.getDown(2)
iffin = t.getDown(3)
uhf = t.getDown(4)
iffout = t.getDown(5)

zoomM, zoomP = trim == 18000, trim == 0

if not switch2 and var.repeat(zoomP, 150):
	mouse.wheel = mouse.wheelMax
if not switch2 and var.repeat(zoomM, 150):
	mouse.wheel = -mouse.wheelMax
if not switch2 and not switch and var.dblClicked(j.getPovDown(0, 2)):
		k.setPressed([ky.LSht, ky.NumberPadEnter], 1000, 300)	

cursorE = t.getPressedBip(0, 200, 200)

cursorZ = j.getPressedBip(18, 600, 200)


aa_mrm, ag_df = t.get3States(8), t.get3States(9)

caution_fack = t.get3States(20)

cycle_ap_pitch, cycle_ap_roll = t.get3States(26), t.get3States(27)

#gearup = t.getDown(21)
#geardn = t.getDown(22)
########################### Disengage Autopilot momentary #######################
if var.sglClicked(t.getDown(25)):
	paddle = not paddle; beep.play(paddle, [1000, 500], [150, 500])
	v.setButton(25, paddle)
	
v.setDigitalPov(0, j.get4Ways([6, 7, 8, 9]))			#tms
v.setDigitalPov(1, j.get4Ways([10, 11, 12, 13]))		#dms
v.setDigitalPov(2, j.get4Ways([14, 15, 16, 17]))		#cms


#v.setButton([0, 1, 2, 3, 4, 5, 6, 7], [trig1, wpn_rel, pinky, cursorE,nws_msl, trig2, afbrkout, afbrkin])
v.setButton(range(0, 8), [trig1, wpn_rel, pinky, cursorE,nws_msl, trig2, spbrkout, spbrkin])

########################### Function switch #####################################
if switch:
	#	cy = up: radar range +, cx = lt: Radar Azimuth Scan Change,
	#		 dn: radar range -,      rt: Radar Bar Scan Change
	k.setPressed(cx, -cy, lim, ctrl_f2, alt_f1, ctrl_f1, alt_f2)
	#############################################################################
	############################# FACK ##########################################
	if caution_fack[1]:									# fack
		k.setPressed(ky.Backspace)
	#############################################################################	
	############################# Mode MRM/DOGFIGHT##############################		
	v.setButton([8, 9], [aa_mrm[0], ag_df[0]]) 	# mode mrm, mode df		#					
	if aa_mrm[1]:																#
		mode += 10																#
		speech.say("Mode MRM OVERT")											#
	if ag_df[1]:																#
		mode += 10																#
		speech.say("Mode canon OVERT")											#
	#############################################################################	
	############################ TIR Gestion ####################################	
	tir_center = j.getPressed(4)                          			#
	tir_pause = j.getPressed(2)                           			#
	k.setPressed([ky.F12], tir_center)                      			#
	k.setPressed([ky.F9], tir_pause)                        			#
	#############################################################################
	############################ Gear Gestion ###################################
	geardn = var.get3States(range_knob > lim)                       			#
	gearup = var.get3States(range_knob < -lim)                      			#
	v.setButton([21, 22], [gearup[0], geardn[0]])	            			#
	speech.say([geardn[1], gearup[1]], ["Train sorti", "Train rentré"])		#	
	#############################################################################
	v.setButton(14, cursorZ)

########################### Function switch2 ####################################
if switch2:
	############################ Trim ###########################################
	v.setButton([10, 11, 12, 13], trim)
	#############################################################################
#################################################################################

v.setDigitalPov(3, var.getPov4Ways(98, Axis.XY, cx, -cy))	# cursor u,r,d,l
v.setButton(20, caution_fack[0])		# master caution

########################### Mode Nav, AA et AG ##################################
if aa_mrm[2] and mode < 9:
	k.setPressed(ky.F5)
	if mode == 1:
		mode = 0
	else:
		mode = 1
	speech.say( mode, modetext)
if ag_df[2] and mode < 9:
	k.setPressed(ky.F6)
	if mode == 2:
		mode = 0
	else:
		mode = 2
	speech.say( mode, modetext)
	
if mode > 9 and (aa_mrm[2] or ag_df[2]):			# retour mode MRM/DF
	v.setButton([8, 9], [False, False])
	mode -= 10
	speech.say(mode, modetext)
#################################################################################
##################### PITCH/ROLL ################################################
v.setButton([26, 27], [cycle_ap_pitch[0], cycle_ap_roll[0]])
if cycle_ap_pitch[1]:
	pitch_mode = (pitch_mode + 1) % 3
	speech.say(pitch_mode, ["Mode pitch off", "Mode pitch attitude", "Mode pitch altitude"])

if cycle_ap_roll[1]:
	roll_mode = (roll_mode + 1) % 3
	speech.say(roll_mode, ["Mode roll attitude", "Mode roll plan", "Mode roll cap"])
#################################################################################
v.setButton([15, 16, 17, 18], [vhf, iffin, uhf, iffout])

frein  = -pedalR > lim and -pedalL > lim
v.setButton(29, frein)
if not frein:
	v.z = rudder
v.x = pitch
v.y = roll
#slider0 ou curseur = droite dans jeu, slider1 ou cadran = gauche dans jeu
v.slider = thr_left
v.dial = thr_right + offset
v.rx = range_knob


"""
s1 = switch on, s2 = toogle dblclicked(s1)
Throttle 			s1				Joystick			s1				Vjoy			
----------------------------------------------------------------------------------------					
00	cursorE							00	trig1							00  trig1	
01       							01	wpn_rel         		        01  wpn_rel 
02  VHF    							02	pinky           tir_pause       02  pinky   
03	IFF IN 							03  switch***          		        03  cursorE	        
04  UHF    							04	nws/msl         tir_center      04  nws/msl     
05  IFF OUT							05	trig2           		        05  trig2   
06  afbrkout						06	tms	up		    		        06  afbrkout
07  afbrkin							07	tms	right	    		        07  afbrkin	
08  mode aa			mode mrm		08	tms	down					    08	mode mrm
09  mode ag			mode df			09	tms	left					    09	mode df
10       							10  dms	up		    		        10	trim u nose d
11									11  dms	right	    		        11	trim r roll r
12                  		        12  dms	down	    		        12  trim d nose u
13                  		        13  dms	left	    		        13  trim l roll l
14                  		        14  cms	up		    		        14	cursorZ
15                  		        15  cms	right	    		        15	VHF
16                  		        16  cms	down	    		        16	IFF IN
17                  		        17  cms	left	    		        17	UHF
18                  		        18  				cursorZ	        18	IFF OUT
19                  		                          		        	19
20  caution			fack	                          		        	20	master_caution
21  		        		                          		        	21  gearup
22  		        		                          		        	22  geardn
23                  		                          		        	23
24                  		                          		        	24
25  paddle          		                          		        	25  paddle
26  cycle_ap_pitch  		                          		        	26  cycle_ap_pitch
27  cycle_ap_roll   		                          		        	27  cycle_ap_roll
28                  		                          		        	28	
29                  		                          		        	29	freinage
30                  		                          		        	30	--?mode aa
31                  		                          		        	31	--?mode ag
															s2 
0U									0U	zoom FOV +		trim u nose d	0U	tms	up		
0R                                  0R  				trim r roll r   0R	tms	right	
0D                                  0D 	zoom FOV -		trim d nose u   0D	tms	down	
0L                                  0L  				trim l roll l   0L	tms	left	
  								   2x0D	reset Zoom						1U  dms	up		
slider	 			    		    	                                1R  dms	right	
-------------------------------------------------------------------     1D  dms	down	
u 	Zoom + TGP      U gearup                                            1L  dms	left	                                                                        
d   Zoom - TGP      D geardn                                            2U  cms	up		
                                                                        2R  cms	right	
                                                                        2D  cms	down	
curseur																	2L  cms	left																			
-------------------------------------------------------------------		3U	radar curs u
cx	curs l/r        AZIMUTH/BAR scan change              		        3R	radar curs r
cy  curs u/d        range radar +/-                                     3D	radar curs d
                                                                        3L	radar curs l
                                                                        
frein appuyé= pedalG + R appuyée 1s (toggle)
"""