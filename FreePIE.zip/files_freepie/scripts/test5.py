def ll1():
	var.AddCommandFromVar("DC;U:NAV1:000000:GG262728:WT84:8000")

def ll():	
	#data = dcs.getDataFromDCS()
	data = [38, -7, 4, 55, 6,130,9,224]
	j = [2, 2, 2 , 4, 6]
	l = [5, 7, 9, 3, 5]
	for i in range(0, 5):
		#j = 2 if i < 3 else 4 if i == 3 else 6
		#l = (5 + i * 2) if i < 3 else (3 + (i - 3) * 2) 
		windto = data[j[i] + 1]
		windfrom = ((windto - 180) if windto > 180 else (windto + 180)) + data[1]
		if windfrom < 1:
			windfrom = windfrom + 360	
		windspeed = int(round(1.94 * data[j[i]], 0)) if i == 0 or i > 2 else int(round(1.94 * data[j[i]] * 2, 0))
		number = list("{0:03d}{1:02d}".format(windfrom, windspeed))
		number.append(l[i])
		windformat = "D0;WCDU_:300:{0}:{1}:{2}:{3}:{4}:LSK_{5}L".format(*number)
		if i == 3:
			var.AddCommandFromVar("D0;FCDU_PG :300:0:1")
		var.AddCommandFromVar(windformat)
		diagnostics.debug("l = " + windformat)
	var.AddCommandFromVar("D0;FCDU_PG :300:2:1")
	alt = [0, 1, 2, 7, 26]	
	for i in range(0, 5):
		#l = (5 + i * 2) if i < 3 else (3 + (i - 3) * 2)
		#alt = i if i < 3 else 7 if i == 3 else 26
		temp = data[0] - 2 * alt[i]
		neg = True if temp < 0 else False
		number = list("{0:02d}".format(abs(temp)))
		number.append(l[i])
		if neg:
			tempformat = "D0;WCDU_:300:{0}:{1}:LSK_{2}R:LSK_{2}R".format(*number)
		else:
			tempformat = "D0;WCDU_:300:{0}:{1}:LSK_{2}R".format(*number)
		if i == 3:
			var.AddCommandFromVar("D0;FCDU_PG :300:0:1")			
		var.AddCommandFromVar(tempformat)
		diagnostics.debug("l = " + tempformat)
	#data[0:8] = []
	#for i in data:
	#	diagnostics.debug("index : {0}, val = {1}", data.index(i), i)
if speech.said("bonjour"):
	beep.play(300)
	ll()	

if speech.said("démarrage"):
	beep.play(300)
	ll1()	
if starting:
	system.setThreadTiming(TimingTypes.HighresSystemTimer)
	system.threadExecutionInterval = 30
	#k, m, v = keyboard, mouse, vJoy[0]
	ddd= dcs

