if starting:
	speech.say("youpi")

if keyboard.getPressed(Key.S):
	Saisir_data("bonjour", "aurevoir", 0)
def Saisir_data(begintext, endtext, mode = 0):
	var.sendCommand("SY;" + begintext + "!KD;79:78!K0!KK;" + str(mode) + "!SY;" + endtext + "!KH;100!KU;79:78")