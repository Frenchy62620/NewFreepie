if starting:
	system.setThreadTiming(TimingTypes.HighresSystemTimer)
	system.threadExecutionInterval = 30
	speech.selectVoice("ScanSoft Sebastien_Full_22kHz")
	#######
	j, t = joystick["Joystick - HOTAS Warthog"], joystick["Throttle - HOTAS Warthog"]
	s = joystick["SideWinder Precision Racing Wheel USB version 1.0"]
	k, m, v = keyboard, mouse, vJoy[0]
	b= beep
	s1 = speech

if speech.said("tester"):
	var.sendCommand("A-10C_test.txt", "TEST5")
