if starting:
	system.setThreadTiming(TimingTypes.HighresSystemTimer)
	system.threadExecutionInterval = 30
	speech.selectVoice("ScanSoft Sebastien_Full_22kHz")
	#######
	j, t = joystick["Joystick - HOTAS Warthog"], joystick["Throttle - HOTAS Warthog"]
	s = joystick["USB  ADAPTOR"] #s = joystick["SideWinder Precision Racing Wheel USB version 1.0"]
	f, k, m, v = filters, keyboard, mouse, vJoy[0]
	t.setRange(-100, 100, [2, 258]) 	# cursor radar cx, cy
	#t.setRange(0, 100, [1282, 1538])	# throttle left and right
	s.setRange(0, 100, [2, 258]) 		# frein differentiel L & R
	bx0, by0 = f.VjoyRange([-100, -95, 82, 100]), f.VjoyRange([-100, -100, 100, 100])	#######
	rx0, ry0 = f.VjoyRange([-100, -95, -3, 3, 95, 100]), f.VjoyRange([-100, -100, 0, 0, 100, 100])	#######
	tx0 = ty0 = [-16383, 16383]
	roll_param = pitch_param = 4

	#speech.compile(["A10C_general.xml", "A10C_cdu.xml"])
	speech.compile(["A10C_master1.xml"])
	speech.loadCFG(["A10C_master1.cfg"])
	#speech.setCFG(["cdu"], False)
	sw0 = sw1 = paddle = viewon = False
	trim = [36, 37, 38, 39]
	lim = 0.9 * 16383
	view, lastview =[5, 6, 5, 4] ,[-1, -1, -1, -1]
	thrX, vjoyX = [0, 100] , [-16383, 16383] #t.MinMaxAxis(4),v.MinMaxAxis
	led1, led2, led3, led4, led5, backlight = 0x1, 0x10, 0x100, 0x1000, 0x10000, 0x100000
	tirpause = Key.Console; tircentre = Key.NumberPad5
	dmsr_lg = dmsl_lg = False
	flag_trim = ravito = False
	deltapower = 0
	bx = []
	EVENT, COMMAND = False, ""

if EVENT and COMMAND:
	if dcs.IsActionFinished():
		exec(COMMAND)
if var.existCommand():
	exec(var.cmd)
if speech.saidFromfile():
	diagnostics.watch(speech.result)
	exec(speech.result)
if speech.said("volets ouvert"):
	beep.play(600)
	var.sendCommand("DX;FLAPS_SWITCH 2")
if speech.said("volets fermé"):
	beep.play(600)
	var.sendCommand("DX;FLAPS_SWITCH 0")
if speech.said("volets moitié"):
	beep.play(600)
	var.sendCommand("DX;FLAPS_SWITCH 1")	
if speech.said("récupérer CDU"):
	beep.play(600)
	var.sendCommand("DI;2:4544:24:4760")
	GET_DATA()
if speech.said("saisir données"):
	Saisir_data()
if speech.said("papa tango"):
	ss = next((s for s in bx if "L/L" in s), None)
	if ss:
		diagnostics.debug(ss)
	else:
		beep.play(200)	
if speech.said("afficher données"):
	GET_DATA()	
#if speech.said("saisir tango"):
#	beep.play(600)
#	CDU_SELECT_SCREEN("WP")
if speech.said("saisir tango"):
	beep.play(600)
	CDU_WP1()
	#CDU_WP(["414141*0424242*200", "TGT10", "123200"])
if speech.said("afficher CDU"):
	CDU_DISPLAY()
if speech.said("avion tester"):
	var.sendCommand("A-10C_test.txt", "TEST1")	
if speech.said("avion démarrer"):
	var.sendCommand("A-10C_startup1.txt", "STARTUP")

if speech.said("avion arrêter"):
	var.sendCommand("A-10C_startup1.txt","SHUTDOWN")

if speech.said("saisir météo"):
	beep.play(600)
	CDU_WINDLASTE([20,-7, 3,74, 3,74, 3,66])
	
if speech.said("saisir balisage"):
	beep.play(600)
	var.sendCommand("A-10C_cdu.txt","NEW_WAYPOINT")

if speech.said("récupérer données"):
	beep.play(600)
	b = dcs.getDataSFromDCS()
	for c in b:
		diagnostics.debug(c)	

if speech.said("saisir course"):
	#var.sendCommand("A10-C_radio.txt", "COURSE_KNOB")
	Saisir_data("Saisir Course", "terminé", 0)
if speech.said("appliquer course"):
	beep.play(600)
	var.sendCommand("DO;4544,24,4760:@C:L/L:*SKIP_LL!DW;CDU_:100:LSK_9R!*SKIP_LL")	
if speech.said("saisir pression"):
	var.sendCommand("A10-C_pressure.txt")
if speech.said("mode plan de vol"):
	var.sendCommand("DX;AAP_STEERPT 0")
if speech.said("mode marque point"):
	var.sendCommand("DX;AAP_STEERPT 1")	
aerofrein = keyboard.getKeyDown(Key.Insert)


alpha = 1	#0.17 if ravito else 1

############################ Pedal Axis (Sidewinder) ########################################
rudder = f.LinearCurve(s.zRotation, rx0, ry0)																								#
#																																														#
BrakeL = f.LinearCurve(min(s.x, 50), bx0, by0, 0, 50)																				#
BrakeR = f.LinearCurve(min(s.y, 50), bx0, by0, 0, 50)																				#
#############################################################################################

############################ Joystick HOTAS #################################################
############################ Joystick Axis																									#
roll, pitch  = f.Joy2Curve(j.x, 4), f.Joy2Curve(j.y,4)																			#
############################ Joystick Pov																										#
#dir = j.getPovDir(0)		 																																		#
############################ Joystick Buttons																								#
sw0 = j.getDown(3) 																									#sw0										#
sw1 = not sw1 if var.dblClicked(sw0) else sw1                       #sw1          					#
#																																														#
trig1, wpnrel = j.getStates(0), j.getStates(1)											#gun PAC, wpn rel				#
trig2 = j.getDown(5)																								#fire										# 
master_mode, nws_laser = j.getDown(4, not sw1), j.getDown(2)				#master mode/NWS_Laser	#
#############################################################################################

############################ Throttle HOTAS #################################################
############################ Throttle Axis																									#
# Throttle gauche et droite t.z, t.zRotation in [0 - 100]  																	#
thr_left, thr_right = t.zRotation, t.z #+ (deltapower if ravito else 0)											#

# Cursor radar X / Y																																				#
cx, cy  = t.x, t.y																																					#
# range_knob                                                                           			#
slider = t.sliders[0]																																				#
############################ Throttle Buttons																								#
redbut, spbrkin = t.getPressed(14), t.getDown(6)										#red button,speedbrake	#
spbrkout = t.getDown(7) or aerofrein						        																		#
boat_fw, boat_bk = t.getDown(8), t.getDown(9)  			          			#boat	            			#
china_fw, china_bk = t.getStates(10), t.getStates(11)            		#china   	        			#
pinky_fw, pinky_bk = t.getDown(12), t.getDown(13)                  	#pinKey              		#
flapsup, flapsdn = t.getDown(21), t.getDown(22)                    	#flaps 									#
# radio																																											#
vhfam_fw, uhf_dn, vhffm_bk = t.getDown(3), t.getDown(4), t.getDown(5)												#
ts_up = t.getDown(2)																																				#
# LASTE Gestion																																							#
eac, rdr =  t.getDown(23), t.getDown(24)                                      							#
apeng, appath, apalt = t.getDown(25), t.getDown(26), t.getDown(27)                      		#
# Engine 																																										#
apu, ldgwarning_caution = t.getDown(19), t.getDown(20)																			#
eng_fuel_l, eng_fuel_r = t.getDown(15), t.getDown(16)																				#
eng_oper_motor_l, eng_oper_motor_r = t.getDown(17), t.getDown(18)														#
eng_oper_ign_l, eng_oper_ign_r = t.getDown(30), t.getDown(31)																#
cutoff_r, cutoff_l = t.getDown(28), t.getDown(29)																						#
#############################################################################################

########################### RUDDER to action ################################################
v.z = rudder                                                                                #
if sw0:                                                                                     #
	gearup = var.getPressed(BrakeL < -16000)																									#
	geardn = var.getPressed(BrakeR < -16000)																									#
	v.setButton([62, 63], [gearup, geardn])	            									#gear up/dn					#
	speech.say([gearup, geardn], ["Train rentré", "Train sorti"])															#	
else:																																												#
	v.ry, v.rz = BrakeL, BrakeR																																#
#############################################################################################

########################### Joystick HOTAS to action ########################################
if not sw1 or (sw1 and not sw0):                                                    				#
	v.x, v.y = roll, pitch																																		#
#																																														#
v.setButton(trim, j.pov[0])								#POV joy						#trim norm/sec	#<************#
v.setButton(43, j.getPressedBip(18, 1000))															#0TRIM push cms			#
v.setButton(44, master_mode)																						#master mode				# 

#k.setPressed([Key.NumberPad5, Key.O], j.getPressed(6))									#view & tir cnter 	#	
#k.setPressed([Key.RightCtrl, Key.O], j.getPressed(8))									#tir pause					#
if ravito:																																									#
	if j.getPressed(6):		#tms u speed +                                                  		#
		deltapower += 1                                                                     		#
	elif j.getPressed(8):	#tms d speed -                                                  		#
		deltapower -=1                                                                      		#
#                                                                                           #
if sw0 and not sw1:																																					#
	v.setButton([60, 61], j.getDown([9, 7]))									#seat dn/up		(tms l/r)					#
	v.setButton([0, 1], j.getDown([8, 6]))										#WP dn/up			(tms d/u)					#
elif sw1 and sw0:                                                                           #
	speech.sayone("pitch " + str(pitch_param) + ", roll " + str(roll_param))                  #
	pitch_param = int((16383 - j.y) / 3640)		                                                #
	roll_param = int((16383 + j.x) / 3640)    	                                              #
else:																																												#
	v.setButton([40, 45, 41, 02], [trig1[0], trig2, wpnrel[0], nws_laser])										#	
	v.setDigitalPov(0, j.getDown([6, 7, 8, 9]))															#tms u,r,d,l   		#	
	v.setDigitalPov(1, j.getDown([10, 11, 12, 13]))													#dms           		#	
	v.setDigitalPov(2, j.getDown([14, 15, 16, 17]))													#cms           		#

	

"""
elif sw1 and not sw0:																		#
	####################### Joystick HOTAS to action switch1 ################################	
	#TRIM	[36, 37, 38, 39]	TRIM SECOURS [56, 57, 58, 59]	bug 56 58 inverse			#
	if j.getPressed(8):								#switch Norm/secours	(TMS down)		#		
		trim = map(lambda x: x-20 if x > 50 else x+20, trim); sec = trim[0]>50				#
		v.setPressed(46)							#set norm or sec EFCP_TRIM_OVERRIDE	0/1	#
		speech.say([not sec, sec], ["compensateur normal", "compensateur de secours"])		#
else:						#Function sw0 and sw1											#
	pass
"""																							#
#############################################################################################

########################### Throttle HOTAS to action ########################################
if sw0:																																											#
	if t.getPressed(30):																			#Tacan Airport (eng_oper_ign_l])#
		ravito = False                                                                          #
		var.sendCommand("A-10C_radio.txt", "TACAN_AIRPORT")																			#
	elif t.getPressed(31):																		#Tacan Ravito (eng_oper_ign_r])	#
		ravito = dcs.getData(4456, 14, 1) == 4																									#
		var.sendCommand("A-10C_radio.txt", "TACAN_AA")																					#
else:                                                                                      	#
	v.setButton([30, 31], [eng_oper_ign_l, eng_oper_ign_r])							#eng oper ign					#
																																														#
v.slider, v.dial = thr_left, thr_right																											#
v.rx = slider																													#zoom FOV           	#
 																																														#
v.setButton([10, 11], [china_fw[0], china_bk[0]])											#china								#
v.setDigitalPov(3, 98, cx, cy)																				#cursor radar u,r,d,l	#
v.setButton([32, 33, 34, 35], t.pov[0])																#coolie								#
v.setButton([6, 7, 8, 9], [spbrkin, spbrkout, boat_fw, boat_bk])			#speedbrake, boat   	#
v.setButton([12, 13], [pinky_fw, pinky_bk]) 													#pinky		      			#
v.setButton([21, 22], [flapsup, flapsdn])															#flaps              	#
# Autopilote LASTE                                                													#
v.setButton([23, 24, 25, 26, 27], [eac, rdr, apeng, appath, apalt])                        	#
# engine																																										#
v.setButton([19, 28, 29], [apu, cutoff_r, cutoff_l])									#apu & engine					#
v.setButton([15, 16], [eng_fuel_l, eng_fuel_r])												#fuel flow						#
v.setButton([17, 18], [eng_oper_motor_l, eng_oper_motor_r])						#eng oper motor				#
v.setButton([20, 42], ldgwarning_caution)															#stop alarms 					#
# radio																																											#
v.setButton([3, 4, 5], [vhfam_fw, uhf_dn, vhffm_bk])									#vhf & uhf						#
#############################################################################################

######################## Led Gestion ########################################################
warthog.setLed([0], sw0 or sw1)																#
warthog.setLed([5], ravito)																	#
#############################################################################################

def radio(device, cmd):
	#AddCommandFromVar(cmd, 2)
	device.setPressed(cmd)

def ils():
	var.AddCommandFromFile("A-10C_radio.txt", "ILS")
def vhf(i):
	var.AddCommandFromFile("A-10C_radio.txt", "VHF_" + i)
def keybut(keys, buttons, id):
	k.setPressedLater(keys, 600, id); v.setPressed(buttons, 500, id)
def mousevjoy(mouse, buttons, id):
	m.setPressedLater(mouse, 600, id); v.setPressedLater(buttons, 500, id)

def cdu(cdukey):
	k.setPressed([Key.LeftCtrl, Key.LeftWindowsKey, cdukey])
def camera(sens):
	k.setPressedLater([Key.RightCtrl, Key.RightShift, sens], 1000, 10)
	k.setPressedLater([Key.NumberPad2], 500, 11)
def tir(action):
	if action == 1:
		k.setPressed(Key.NumberPad5)		#center
	if action == 2:
		k.setPressed([Key.LeftCtrl, Key.O])	#pause

def CDU_GetData(numline = 0, search = ""):
	d, f = 0, 10
	if numline > 0:
		d = numline - 1; f = d + 1
	for i in range(d, f):
		val = dcs.getData(4544 + i * 24, 24)
		if search in val:
			return i + 1
	return 0

def CDU_DISPLAY():
	for i in range(0, 10):
		address = 4544 + i * 24
		diagnostics.debug("{0} : [{1}]".format(i, dcs.getData(address, 24)))		

def BEARING(act = "CRS"):	#CRS or HDG
	address =  4442 if act == "CRS" else 4444
	newheading_deg = dcs.getDataIFromDCS()[0]
	returntozero = -round((dcs.getData(address, 65535, 0) * 360.0 / 57.29), 0)
	newheading = round((newheading_deg * (65535 / 57.29)), 0)
	cmd = "DX;HSI_{2}_KNOB {0}!T0;100!DX;HSI_{2}_KNOB {1}".format(returntozero, newheading, act);
	var.sendCommand(cmd)

# [37T*AA1234512345*200, 0 : [ WAYPT   F1  1    D5/B1 ] 0 : [ OFFSET  F1  1    D5/B1 ]
# [North*Est*Elev, ]
def CDU_SELECT_SCREEN(data):
	cmd = ["DW;CDU_:100:{0}".format(data)]
	cmd.append("!SY;En attente de saisie!KD;79:78!K0!KK;5!KH;100!KU;79:78")
	var.sendCommand(''.join(cmd))

def CDU_WP1():
	data = dcs.getDataSFromDCS() #dcs.getDataFromBuffer()
	cmd = ["0;NOP"]	
	dtot = next((s for s in data if len(s) == 6 and s.isdigit()), None)	#5R
	wp = next((s for s in list(data)[1:] if len(s) < 6 or "-" in s), None) #7R if new or 3R/3L if exist string/num
	diagnostics.watch(wp)
	ss = next((s for s in data if '*' in s), None)
	hh = next((s for s in data if '.' in s), None)
	if "0" in data[0]:
		cmd.append("!DO;4544,24,4760:@C:L/L:*SKIP_LL!DW;CDU_:100:LSK_9R!*SKIP_LL")
		#cmd.append("!DW;CDU_:100:LSK_{0}R!*SKIP_LL".format(9 - screen * 6))
		cmd.append("!DW;CDU_:100:")		
		for w in wp.split('-'):
			cmd.append( ("{}:"*len(w)).format(*list(w)) )
			cmd.append("LSK_3{0}".format("L" if w.isdigit() or len(w) == 1 else "R"))
			cmd.append("!D1;1:2,3,5,6,8-10:4688:24!DW;CDU_:100:{0}:LSK_7L:")
		cmd.append("CLR")
		diagnostics.watch(''.join(cmd))
		var.sendCommand(''.join(cmd))

def CDU_WP():
	#cdutm = CDU_GetData(9, "UTM")  	#Ecran on UTM coord.
	"""
	global EVENT; global COMMAND
	if not EVENT:
		cmd = ["DW;CDU_:100:WP:LSK_3R"]
		cmd.append("!SY;SAISIR DATA WP!KD;79:78!K0!KK;5!KH;100!KU;79:78")
		var.sendCommand(''.join(cmd))
		EVENT = True
		COMMAND = "CDU_WP()"
		return
	EVENT = False
	"""
	screen = 0; newwp = False
	if "OFFSET" in dcs.getData(4544, 24):
		screen = 1
	data = dcs.getDataSFromDCS() #dcs.getDataFromBuffer()
	cmd = ["DW;CDU_:100:"]	
	dtot = next((s for s in data if len(s) == 6), None)	#5R
	wp = next((s for s in data if len(s) < 6), None) #7R if new or 3R/3L if exist string/num
	ss = next((s for s in data if '*' in s), None)
	hh = next((s for s in data if '.' in s), None)
	#diagnostics.watch("wp = {0}, ss = {1}".format(wp, ss))	
	
	if ss:
		cd = ss.split("*")					#cd[0] = N, cd[1] = E, cd[2] = Elevation, 7L, 9L, 5L
		if len(cd[0]) == 3:	#UTM
			cmd.append("!DO;4544,24,4760:@C:UTM:*SKIP_UTM")			
			cmd.append("!DW;CDU_:100:LSK_{0}R!*SKIP_UTM".format(9 - screen * 6))
		else:
			cmd.append("!DO;4544,24,4760:@C:L/L:*SKIP_LL")
			cmd.append("!DW;CDU_:100:LSK_{0}R!*SKIP_LL".format(9 - screen * 6))
		cmd.append("!DW;CDU_:100:")
		if len(cd) > 1:			#saisir N
			cmd.append( ("{}:"*len(cd[0])).format(*list(cd[0])) ); cmd.append("LSK_7L:")
			if len(cd[1]) > 0:	#saisir E
				newwp = True
				if cd[1][0] != '0' and cd[1][0] != '1':
					cd[1] = "a{0}".format(cd[1])
				cmd.append( ("{}:"*len(cd[1])).format(*list(cd[1]))	); cmd.append("LSK_9L:")
			if len(cd) > 2:
				cmd.append( ("{}:"*len(cd[2])).format(*list(cd[2]))	); cmd.append("LSK_5L:")
	
	if wp:			#WPT NAME OR DIGIT
		cmd.append( ("{}:"*len(wp)).format(*list(wp)) )
		cmd.append("LSK_7R" if newwp else "LSK_3{0}".format("L" if wp.isdigit() else "R"))		
	if dtot:
		cmd.append( ("{}:"*len(dtot)).format(*list(dtot)) ); cmd.append("LSK_5R:")
	if hh:
		t = ("{}:"*len(hh)).format(*list(hh)).replace(".", "POINT")
		cmd.append( t ); cmd.append("LSK_5R:")
	cmd.append("CLR")
	var.sendCommand(''.join(cmd))	
	diagnostics.watch(''.join(cmd))

def CDU_OSET(data):	# ["N/E", "L/U", "NAME", "DTOT", "INIT", "HHHDDD", "ELEVATION"] 
	cmd = ["DW;CDU_:100:OSET"]
	namewp = (":{}"*len(data[2])).format(*list(data[2]))
	umts = ":LSK_3R" if data[1] == "U" else ""
	for i in range(4, 6):
		if len(data) > i and len(data[i]) > 1:	
			cmd.append((":{}"*len(data[i])).format(*list(data[i])))
			cmd.append(":LSK_5L" if i == 4 else ":LSK_5R")
	cmd.append(namewp); cmd.append(":LSK_7R")
	cmd.append(":WP:LSK_3R"); cmd.append(namewp); cmd.append(":LSK_3R")
	if len(data) > 6 and len(data[6]) > 1:
		cmd.append((":{}"*len(data[6])).format(*list(data[6]))); cmd.append(":LSK_5L")	
	if len(data) > 3 and len(data[3]) == 6:	
		cmd.append((":{}"*6).format(*list(data[3]))); cmd.append(":LSK_5R") 
	var.sendCommand(''.join(cmd))

def CDU_FPM(data):	#	["namefpm", "nbwp", "n", "A"]
	#nbwp = int(data[1])
	cmd = ["DW;CDU_:100:FPM"]
	cmd.append((":{}"*len(data[0])).format(*list(data[0]))); cmd.append(":LSK_9L:LSK_5R")
	for w in reversed(data[1:-1]):
		cmd.append((":{}"*len(w)).format(*list(w))); cmd.append(":LSK_3R:LSK_5L")
	cmd.append(":FPM")	
	if data[-1] == "A":
		cmd.append(":LSK_5L:LSK_5L")
	var.sendCommand(''.join(cmd))

def CDU_WINDLASTE(data):
	#data = dcs.getDataIFromDCS()
	#data = [20,-7, 3,74, 3,74, 3,66]
	cmd = ["DW;CDU_:100:SYS:LSK_3R:LSK_9R:LSK_7R:LSK_7R!"]	#SYS, LASTE, WIND, CLRx2
	j, l, alt = [2, 2, 2, 4, 6], [5, 7, 9, 3, 5], [0, 1, 2, 7, 26]
	#Saisir altitude
	for i in range(5):
		if i == 3:
			cmd.append("DF;CDU_PG :100:0:1!")	
		lg = list("{0:02d}{1}".format(alt[i], l[i]))
		cmd.append("DW;CDU_:100:{0}:{1}:LSK_{2}L!".format(*lg))
	cmd.append("DF;CDU_PG :100:2:1!DW;CDU_:100:LSK_5R!")
	for i in range(5):
		windto = data[j[i] + 1]
		windfrom = windto + data[1] + (-180 if windto > 180 else 180)
		if windfrom < 1:
			windfrom += 360;      
		windspeed = data[j[i]]
		windspeed = int(round(1.94 * (windspeed * (2 if i== 1 or i == 2 else 1)), 0))
		temp = data[0] - 2 * alt[i]
		if i == 3:
			cmd.append("DF;CDU_PG :100:0:1!")
		lg = list("{0:03d}{1:02d}{2}{3:02d}".format(windfrom, windspeed, l[i], abs(temp)))
		cmd.append("DW;CDU_:100:{0}:{1}:{2}:{3}:{4}:LSK_{5}L:{6}:{7}:LSK_{5}R!".format(*lg))
		if temp < 0:
			cmd.append("DW;CDU_:100:LSK_{5}R!".format(*lg))			
	cmd.append("DF;CDU_PG :100:2:1")
	var.sendCommand(''.join(cmd))

def GET_DATA():
	diagnostics.debug("data =")
	global bx
	bx = dcs.getDataSFromDCS()
	i = 0
	for c in bx:
		i = i + 1
		diagnostics.debug("{0:02d} - ={1}=".format(i, c))


def Saisir_data(begintext = "", endtext = "", command = "", mode = 5):	#mode 5 = Alpha + Azerty 1 + 4
	cmd = [""]; cmd.append("SY;{0}!KD;79:78!K0!KK;{2}!SY;{1}!KH;100!KU;79:78".format(begintext, endtext, mode)) 
	var.sendCommand(''.join(cmd))
"""
sw0 = switch on, sw1 = toogle dblclicked(sw0)
Throttle 			sw0				Joystick			sw0				Vjoy			
----------------------------------------------------------------------------------------			
00	cursorE							00	trig1												00	WP-			    						32  coolie_u								64   
01       								01	wpn_rel         		        01  WP+			    	33  coolie_r                65   
02  mic up  						02	nws/laser	      		       	02  nws/laser	    34  coolie_d                66   
03	mic fw 							03  ***sw0***       ***sw1***   03  mic fw	  35  coolie_l                67   
04  mic dn 							04	master_mode       			    04  mic dn		    36  trim_nose_d     	68  trim_secours          
05  mic bk							05	trig2           		        05  mic bk        37  trim_roll_r       	69  trim_secours          
06  spbrkout						06	tms_up		  wp+							06  spbrkin     38  trim_nose_d             		70	trim_secours 
07  spbrkin							07	tms_right	  seatup       		07  spbrkout	   		39  trim_roll_l	            71	trim_secours 
08  boat fw							08	tms_down		wp-				    	08	boat fw         40	trig1                   72	coolie_u_vocal 
09  boat bk							09	tms_left		seatdn		    	09	boat bk         41	wpnrel                  73  coolie_r_vocal 
10  china fw						10  dms_up		    		        	10	china fw        42	master_caution(20)      74        
11	china bk						11  dms_right	    		        	11	china bk        43  RAZ trim                75	coolie_l_vocal 
12  pinky fw           	12  dms_down	    		        	12  pinky fw       	44  master_mode             76                        
13  pinky bk           	13  dms_left	    		        	13  pinky bk       	45	trig2                   77	                      
14  redbut              14  cms_up		  			       		14			        		46  Compens. norm/secours   78	                      
15  engfuel_l         	15  cms_right	    		        	15	engfuel_l       47	                        79	                      
16  engfuel_r          	16  cms_down	  			        	16	engfuel_r       48	                        80	                      
17  engopermotor_l     	17  cms_left	    		        	17	engopermotor_l  49	                        81                        
18  engopermotor_r     	18  push 					        			18	engopermotor_r  50	                        82	                      
19  apu                		                          		19  apu  						51                          83                        
20  ldg_warning				                          		  	20	ldg_warning(42) 52	                        84                        
21  flapsup		        	                          			21  flapsup         53                          85                        
22  flapsdn		        	                          			22  flapsdn         54                          86                        
23  eac                		                          		23  eac		        	55                          87                        
24  rdr                		                          		24  rdr		        	56  trimsec_nose_d  	    	88                        
25  apeng	          		                          			25  apeng           57  trimsec_roll_r          89                        
26  appath					                          		    	26  appath		    	58  trimsec_nose_d          90	                      
27  apalt   		                          		        	27  apalt		    		59  trimsec_roll_l          91	                      
28  eng_r_cutoff       		                          		28	eng_r_cutoff    60 	Seat-                   92	              
29  eng_l_cutoff       		                          		29	eng_l_cutoff    61 	Seat+                   93                
30                  		                          			30	engoperign_l    62	gearup                  94 spdbrkin
31                  		                          			31	engoperign_r    63  geardn                  95 spdbrkout
															 
0U	coolie u						0U	Cockpit view			0U	tms	up			1U  dms	up			2U  cms	up		3U	radar curs u 
0R  coolie r            0R  							   	0R	tms	right		1R  dms	right		2R  cms	right	3R	radar curs r 
0D  coolie d            0D 	Rear View					0D	tms	down		1D  dms	down		2D  cms	down	3D	radar curs d 
0L  coolie l            0L  							   	0L	tms	left		1L  dms	left		2L  cms	left	3L	radar curs l 
  								   2x0D	reset Zoom						
slider	 			    		    	                                							
-------------------------------------------------------------------     	
u 	Zoom FOV + 		U gearup                                           		 	                                                                       
d   Zoom FOV -    D geardn                                            	
                                                                        
                                                                        
curseur																																			
-------------------------------------------------------------------		
cx	curs l/r        AZIMUTH/BAR scan change              		        
cy  curs u/d        range radar +/-                                     
                                                                        
                                                                        
frein appuye = pedalG + R appuy�e 1s (toggle)

  <Joystick_Name ID="1">Joystick - HOTAS Warthog</Joystick_Name>
  <Joystick_Char Buttons="19" Axis="2" POV="1">
    <AXIS Id="2" MinVal="0" MaxVal="65535">Axe X</AXIS>
    <AXIS Id="258" MinVal="0" MaxVal="65535">Axe Y</AXIS>

  <Joystick_Name ID="4">Throttle - HOTAS Warthog</Joystick_Name>
  <Joystick_Char Buttons="32" Axis="5" POV="1">
    <AXIS Id="2" MinVal="0" MaxVal="65535">Axe X</AXIS>
    <AXIS Id="258" MinVal="0" MaxVal="65535">Axe Y</AXIS>
    <AXIS Id="514" MinVal="0" MaxVal="65535">Curseur</AXIS>
    <AXIS Id="1282" MinVal="0" MaxVal="65535">Rotation Z</AXIS>
    <AXIS Id="1538" MinVal="0" MaxVal="65535">Axe Z</AXIS>

  <Joystick_Name ID="3">SideWinder Precision Racing Wheel USB version 1.0</Joystick_Name>
  <Joystick_Char Buttons="8" Axis="3" POV="0">
    <AXIS Id="2" MinVal="0" MaxVal="65535">Axe X</AXIS>
    <AXIS Id="258" MinVal="0" MaxVal="65535">Axe Y</AXIS>
    <AXIS Id="1282" MinVal="0" MaxVal="65535">Rotation Z</AXIS>

v.slider, v.dial = thr_left, thr_right                                                      #
v.rx = zoom if not sw0	else v.rx										#zoom FOV
v.x, v.y, v.z = roll, pitch, rudder	

if speech.said("mission plan de vol"):
	beep.play(300)
	CDU_AddWP()
if speech.said("ajoute plan de vol"):
	beep.play(300)
	CDU_AddFPM()

def CDU_AddWP():
	CDU_WP(["N", "L", "N1", "*", "414151", "0415451", "8000"])
	CDU_WP(["N", "L", "N2", "*", "415737", "0421342", "10000"])
	CDU_WP(["N", "U", "N3", "*", "37T", "GG2923661948", "12000"])      #GG2923661948 37T WG84                                              
	CDU_OSET(["O", "L", "N4", "*", "BULL", "030033", "8000"])

def CDU_AddFPM():
	CDU_FPM(["ABC", "N1", "N2", "N3", "N4", "N"])


# View	[ , r, u, l] last view                                     							#
#if not sw0 and not sw1:																	#
#	if var.getPressed(dir >=0):					                                          	#
#		joydir = dir                                                                        #
#	timerdir = var.heldDown(dir >= 0, 500)                                                	#
#	if var.getPressed(timerdir):                                                            #
#		viewon = not viewon                                                                 #
#		k.setPressed([Key.RightCtrl, Key.NumberPad0, Key.O])		#view cockpit & tir ctr #
#		lastview[0] = -2																	#
#	if var.getReleased(dir >= 0):                                                           #
#		if lastview[0] == -2:																#
#			lastview[0:4] = [-1, -1, -1, -1]												#
#		if viewon:                                              	                        #
#			dispview()													            	    #
#		else:                                                                               #
#			k.setPressed([Key.F1], joydir == 0)						#view cokpit        	#
#			k.setPressed([Key.F4], joydir == 2)	            		#view rear	        	#
#                                                                                           #
#def dispview():																			#
#	if view[joydir] == lastview[joydir]:                                 					#
#		view[joydir] = 9 if view[joydir]== 6 else (view[joydir] + 3) % 9	            	#
#	joykey = [k.intTOkey(int(Key.NumberPad0) + view[joydir])]		          	        	#
#	k.setPressed(joykey)                                                             		#
#	lastview[1:4] =[-1, -1, -1]; lastview[joydir] = view[joydir]; lastview[0] = -1			#
#																							#

"""